var LoadTestingSession = require("./loadTestingSession.js");

function MyCustomTest(redlineApi, testNum, rand, config)
{
	// Redline API
	this.redlineApi = redlineApi;

	// Test info
	this.testNum = testNum;
	this.rand = rand;

	// INI Config
	this.config = config;

	this.url = "https://sslspdy.com/";
	this.minDelayMs = 500;
	this.maxDelayMs = 10000;
	this.delayRangeMs = this.maxDelayMs - this.minDelayMs + 1;

	this.remainingIterations = 1;
}

/** Run test */
MyCustomTest.prototype.runTest = function(callback)
{
	var that = this;

	// Set delay
	var delay = 1;
	if (this.delayRangeMs != 0)
		delay = Math.floor((Math.random()*this.delayRangeMs)+this.minDelayMs);

	// Make request after timeout
	console.log("Making request to " + that.url + " in " + delay + "ms.");
	setTimeout(function() {
		try
		{
			that.loadPage(that.url, function(failed) {
				// Iteration complete
				that.remainingIterations--;

				// Another iteration?
				if (!failed && that.remainingIterations > 0)
					that.runTest(callback);
				else
				{
					// Callback
					if (callback)
						callback.call(that, failed);
				}
			});
		} catch (e) {
			// Callback
			if (callback)
				callback.call(that, failed);
		}
	}, delay);
};

/** Load Page */
MyCustomTest.prototype.loadPage = function(pageUrl, callback)
{
	var that = this;
	// Resource loading?
	var loadResources = false;
	var loadTestSess = new LoadTestingSession(that.testNum, that.redlineApi, loadResources);
	loadTestSess.loadPage(pageUrl, function(failed) {
		// Callback
		if (callback)
			callback.call(that, failed);
	});
};

module.exports = MyCustomTest;
